## Bienvenido a mi editor de texto
tarea realizada para la materia de "Diseño Centrado en el Usuario" (DCU)
- by: Inocencio Junior Avila Gonzalez
- Matricula: 2021-0836
## captura del proyecto
![](Captura%20del%20editor.png)
